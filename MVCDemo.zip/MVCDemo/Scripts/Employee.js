﻿
$(document).ready(function () {


    //State details by country id  

    $("#Country_Id").change(function () {
        var CountryId = parseInt($(this).val());

        if (!isNaN(CountryId)) {
            var ddlState = $('#State_Id');
            ddlState.empty();
            ddlState.append($("<option></option>").val('').html('Please wait ...'));
            $.ajax({
                url: 'http://localhost:61470/api/CascadingDetails/StateDetails?CountryId='+CountryId,
                type: 'GET',
                dataType: 'json',
                data: { CountryId: CountryId },
                success: function (d) {

                    ddlState.empty(); // Clear the please wait  
                    ddlState.append($("<option></option>").val('').html('Select State'));
                    $.each(d, function (i, states) {
                        ddlState.append($("<option></option>").val(states.Id).html(states.Name));
                    });
                },
                error: function (err) {
                    alert(err);
                }
            });
        }


    });

    //City Bind By satate id  
    $("#State_Id").change(function () {
        var StateId = parseInt($(this).val());
        if (!isNaN(StateId)) {
            var ddlCity = $('#City_Id');
            ddlCity.append($("<option></option>").val('').html('Please wait ...'));

            debugger;
            $.ajax({
                url: 'http://localhost:61470/api/CascadingDetails/CityDetails?StateId=' + StateId,
                type: 'GET',
                dataType: 'json',
                data: { stateId: StateId },
                success: function (d) {


                    ddlCity.empty(); // Clear the plese wait  
                    ddlCity.append($("<option></option>").val('').html('Select City Name'));
                    $.each(d, function (i, cities) {
                        ddlCity.append($("<option></option>").val(cities.Id).html(cities.Name));
                    });
                },
                error: function () {
                    alert('Error!');
                }
            });
        }
    });
});
//Load Data function
function loadData() {
    $.ajax({
        url: "/Home/List",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.EmployeeID + '</td>';
                html += '<td>' + item.Name + '</td>';
                html += '<td>' + item.Age + '</td>';
                html += '<td>' + item.State + '</td>';
                html += '<td>' + item.Country + '</td>';
                html += '<td><a href="#" onclick="return getbyID(' + item.EmployeeID + ')">Edit</a> | <a href="#" onclick="Delele(' + item.EmployeeID + ')">Delete</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
//Add Data Function
function Add() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        EmployeeID: $('#Id').val(),
        Name: $('#Name').val(),
        Post: $('#Post').val(),
        State_Id: $('#State_Id').val(),
        Country_Id: $('#Country_Id').val(),
        City_Id: $('#City_Id').val(),
        DOB: $('#DOB').val()
    };
    $.ajax({
        url: "/Employee/AddEmployee",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            window.location.href = result.redirectTo;
        },
        error: function (errormessage) {

        }
    });
}

//function for updating employee's record
function Update() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        ID: $('#Id').val(),
        Name: $('#Name').val(),
        Post: $('#Post').val(),
        State_Id: $('#State_Id').val(),
        Country_Id: $('#Country_Id').val(),
        City_Id: $('#City_Id').val(),
    };
    $.ajax({
        url: "/Employee/Update",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            window.location.href = result.redirectTo;
        },
        error: function (errormessage) {

        }
    });
}
//function for deleting employee's record
function Delele(ID) {
    var ans = confirm("Are you sure you want to delete this Record?");
    if (ans) {
        $.ajax({
            url: "/Home/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {

            },
            error: function (errormessage) {

            }
        });
    }
}
//Function for clearing the textboxes
function clearTextBox() {
    $('#Name').val("");
    $('#Post').val("");
    $('#State').val("");
    $('#Country').val("");
    $('#btnUpdate').hide();
    $('#btnAdd').show();
    $('#Name').css('border-color', 'lightgrey');
    $('#Post').css('border-color', 'lightgrey');
    $('#State').css('border-color', 'lightgrey');
    $('#Country').css('border-color', 'lightgrey');
}
//Valdidation using jquery
function validate() {
    alert($('#Country_Id').val());
    var isValid = true;
    if ($('#Name').val().trim() == "") {
        $('#Name').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Name').css('border-color', 'lightgrey');
    }
    if ($('#Post').val().trim() == "") {
        $('#Post').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Post').css('border-color', 'lightgrey');
    }
    if ($('#State_Id').val().trim() == "") {
        $('#State_Id').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#State_Id').css('border-color', 'lightgrey');
    }
    
    if ($('#Country_Id').val() == "0") {
        $('#Country_Id').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Country_Id').css('border-color', 'lightgrey');
    }
    return isValid;
}