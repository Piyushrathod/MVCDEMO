﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCDemo.BusinessLogic
{
	public class CascadingLogic
	{
		MVCDemoEntities2 dbEntity = new MVCDemoEntities2();

		public List<Country> BindCountry()
		{
			this.dbEntity.Configuration.ProxyCreationEnabled = false;

			List<Country> lstCountry = new List<Country>();
			try
			{
				lstCountry = dbEntity.Countries.ToList();
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
			return lstCountry;
		}

		public List<State> BindState(int countryId)
		{
			List<State> lstState = new List<State>();
			try
			{
				this.dbEntity.Configuration.ProxyCreationEnabled = false;

				lstState = dbEntity.States.Where(a => a.Country_Id == countryId).ToList();
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
			return lstState;
		}

		public List<City> BindCity(int stateId)
		{
			List<City> lstCity = new List<City>();
			try
			{
				this.dbEntity.Configuration.ProxyCreationEnabled = false;

				lstCity = dbEntity.Cities.Where(a => a.State_Id == stateId).ToList();
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
			return lstCity;
		}
	}
}