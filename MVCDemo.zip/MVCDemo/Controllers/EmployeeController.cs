﻿using MVCDemo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemo.Controllers
{
	public class EmployeeController : Controller
	{
		MVCDemoEntities2 empEntity = new MVCDemoEntities2();
		// GET: Employee
		public ActionResult Index()
		{
			var empList = empEntity.Employees.Include("City").ToList();
			ViewBag.CountryList = empEntity.Countries.ToList();
			return View(empList);
		}

		[Route("/Index/Add")]
		public ActionResult Add()
		{
			ViewBag.Countries = empEntity.Countries.ToList();
			return View();
		}

		[HttpGet]
		public ActionResult Edit(int id)
		{
			var emp = empEntity.Employees.Where(e => e.Id == id).FirstOrDefault();
			ViewBag.Countries = empEntity.Countries.ToList();

			ViewBag.States = empEntity.States.Where(c => c.Country_Id == emp.Country_Id);

			ViewBag.Cities = empEntity.Cities.Where(c => c.State_Id == emp.State_Id);
			return View(emp);
		}

		public JsonResult Update(Employee emp)
		{
			var eemp = empEntity.Employees.Where(e => e.Id == emp.Id).FirstOrDefault();
			eemp.Name = emp.Name;
			eemp.Post = emp.Post;
			eemp.City_Id = emp.City_Id;
			eemp.State_Id = emp.State_Id;
			eemp.Country_Id = emp.Country_Id;
			empEntity.SaveChanges();
			return Json(new
			{
				redirectTo = Url.Action("Index", "Employee"),
			}, JsonRequestBehavior.AllowGet);
		}

		public JsonResult AddEmployee(Employee emp)
		{
			empEntity.Employees.Add(emp);
			empEntity.SaveChanges();
			return Json(new
			{
				redirectTo = Url.Action("Index", "Employee"),
			}, JsonRequestBehavior.AllowGet);
		}

		public ActionResult Delete(int id) {
			var eemp = empEntity.Employees.Where(e => e.Id == id).FirstOrDefault();
			empEntity.Employees.Remove(eemp);
			empEntity.SaveChanges();
			return RedirectToAction("Index");
		}
	}
}