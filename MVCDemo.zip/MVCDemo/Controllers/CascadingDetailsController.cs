﻿using MVCDemo.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MVCDemo.Controllers
{
	[RoutePrefix("api/CascadingDetails")]
	public class CascadingDetailsController : ApiController
	{
		public CascadingDetailsController() {

		}
		// GET api/<controller>
		CascadingLogic objCasc = new CascadingLogic();
		[HttpGet]
		[Route("CountryDetails")]
		public List<Country> BindCountryDetails()
		{


			List<Country> countryDetail = new List<Country>();
			try
			{
				countryDetail = objCasc.BindCountry();
			}
			catch (ApplicationException ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadRequest, ReasonPhrase = ex.Message });
			}
			catch (Exception ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadGateway, ReasonPhrase = ex.Message });
			}

			return countryDetail;
		}

		[HttpGet]
		[Route("StateDetails")]
		public List<State> BindStateDetails([FromUri]int CountryId)
		{

			List<State> stateDetail = new List<State>();
			try
			{
				stateDetail = objCasc.BindState(CountryId);
			}
			catch (ApplicationException ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadRequest, ReasonPhrase = ex.Message });
			}
			catch (Exception ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadGateway, ReasonPhrase = ex.Message });
			}

			return stateDetail;
		}

		[HttpGet]
		[Route("CityDetails")]
		public List<City> BindCityDetails(int stateId)
		{
			List<City> cityDetail = new List<City>();
			try
			{
				cityDetail = objCasc.BindCity(stateId);
			}
			catch (ApplicationException ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadRequest, ReasonPhrase = ex.Message });
			}
			catch (Exception ex)
			{
				throw new HttpResponseException(new HttpResponseMessage { StatusCode = HttpStatusCode.BadGateway, ReasonPhrase = ex.Message });
			}

			return cityDetail;
		}
	}
}